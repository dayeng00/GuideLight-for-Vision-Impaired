/home/carl/usb-serial-option/20200516/v4.15.1/./drivers/usb/serial/qcserial.ko
/home/carl/usb-serial-option/20200516/v4.15.1/./drivers/usb/serial/qcserial.o

