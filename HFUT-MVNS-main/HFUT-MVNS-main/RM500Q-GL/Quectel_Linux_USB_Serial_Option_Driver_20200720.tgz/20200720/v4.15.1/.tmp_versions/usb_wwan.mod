/home/carl/usb-serial-option/20200516/v4.15.1/./drivers/usb/serial/usb_wwan.ko
/home/carl/usb-serial-option/20200516/v4.15.1/./drivers/usb/serial/usb_wwan.o

